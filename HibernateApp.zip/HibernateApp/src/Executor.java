import com.mbstu.entity.Connector;
import com.mbstu.entity.Student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

/**
 * Created by habib on 5/10/17.
 */
public class Executor {

    public static void main(String[] args) {

//        Connector conn = new Connector();

        Session session = Connector.getSession();
        session.beginTransaction();

        // insert
        Student student = new Student();
        student.setName("Habib2");
        student.setfName("X");
        student.setRoll("IT-08002");
        session.save(student);

        //        Student student = (Student) session.load(Student.class,1l);
//        session.delete(student);
        session.getTransaction().commit();
    }
}
